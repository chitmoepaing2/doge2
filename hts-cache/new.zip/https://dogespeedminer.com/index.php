

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>DogeSpeedMiner.com - Invest like rich</title>
      <link href="img/dogeminer-favicon.png?s=17032018" rel="shortcut icon" type="image/x-icon" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style2.css?s=03042018-99994">
	   
	   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119885155-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119885155-1');
</script>

      <style>
         #blink5 {
         -webkit-animation: blink5 2s linear infinite;
         animation: blink5 2s linear infinite;
         }
         @-webkit-keyframes blink5 {
         0% { color: rgb(0, 0, 0); }
         50% { color: rgb(125, 4, 40); }
         100% { color: rgb(237, 8, 77); }
         }
         @keyframes blink5 {
         0% { color: rgb(0, 0, 0); }
         50% { color: rgb(125, 4, 40); }
         100% { color: rgb(237, 8, 77); }
         }
      </style>
   </head>
   <body>
      <div class="topmenu">
         <div class="container">
            <ul>
               <li><a href="/index.php">Home</a></li>
			                  <li><a href="/payouts.php">Stats</a></li>
               
               <li><a href="/faq.php">FAQ</a></li>
               <li><a href="/contacts.php">Contacts</a></li>
            </ul>
            <div class="clearfix"></div>
         </div>
      </div>
      <div class="top-bar">
         <div class="container">
            Mining begins immediately. DogeSpeedMiner Free Version 2% per day for 30 days.
         </div>
      </div>
      <a href="#" class="logo-block">
          <span id='logo-change' class="logo"></span>
      </a>
	   
	   	   



 <div class="top-bg" id="header">
         <div class="top-bg-dark"></div>
         <div class="container">
            <div class="input-mine">
               <h1>Reliable online wallet for Dogecoin</h1>
               <p>It's very easy: your mining equipment launches after registration. Once you have set up your account, you can start earning your first coins from our Dogecoin cloud mining service!</p>
               <input type="text" title="34 characters" maxlength="34" id="go_address" placeholder="Enter Your Dogecoin Address" class="form-control">
               <button class="but-hover" type="button" id="go_enter" onclick="go_enter()">Start mining</button>
               <div class="clearfix"></div>
               <div class="head-login" id="enter_result" style="display:none;">
                  <div class="login-info">
                     <div id="result"></div>
                  </div>
               </div>
               <div class="head-social">
                  <a href="#" target="_blank"><span style="font-size: 14px;"><img src="img/twite.png" alt="Twitter"> Twitter</span></a>
                  <a href="#" target="_blank"><span style="font-size: 14px;"><img src="img/teleg.png" alt="Telegram"> Telegram</span></a>
               </div>
            </div>
         </div>
      </div>


<div class="serv-mine white-box">
         <div class="container">
            <div class="serv-mine-item">
               <div class="serv-mine-img">
                  <img class="img-responsive center-block" src="img/tarif/6.png" style="height: 220px;" />
               </div>
               <div class="serv-mine-info">
                  <h2>DogeSpeedMiner All Stats</h2>
                  <div class="row">
                     <div class="col-md-6">
                        Miner speed:
                        <span>10 DH/s</span>
                     </div>
                     <div class="col-md-6">
                        Daily percent:
                        <span>2 %</span>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        Earning Rate:
                        <span>0.00013889 Doge/min</span>
                     </div>
                     <div class="col-md-6">
                        Daily profit:
                        <span>0.20000000 Doge</span>
                     </div>
                  </div>
               </div>
               <div class="clearfix"></div>
            </div>
         </div>
      </div>




     





      
      <div class="serv-price">
         <div class="container">
			 

			 <br>
			 
			 
            <h2 id="plans">Find a your right miner <font id='doge-pro2' style="color:#1d618c; display:none;">Pro</font></h2>
            <div id='doge-def2' class="serv-price-small clearfix">
               Cloud mining is greatly suited for novice miners who would like to try out mining and earning cryptocurrency as well as seasoned miners who don't want the hassle or risks spend time on home mining equipment maintenance.
            </div>

            <div id='doge-pro3' class="serv-price-small clearfix" style="display:none;">
               Cloud mining is suitable for more experienced miners.
            </div>
            <div class="row" id='doge-def4'>
               <div class="col-md-3">
                  <div class="price-box">

                     <img class="img-responsive center-block" src="img/tarif/1.png" style="width:140px; padding-top: 115px; padding-bottom: 20px;" alt="Version 1.0" />

                     <h3>DogeSpeedMiner v1.0</h3>
                     Earning rate:<br />
                     14.7 Doge per day<br />
                     4.9% for 30 days<br />
                     <span>Affiliate bonus 5%</span>
                     <button type="button" class="price-button lgb" onclick="go_deps(300)">Buy for 300 &#208;</button>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="price-box">
                     <div style="height:180px;">
                        <img class="img-responsive center-block" src="img/tarif/2.png" style="width:140px; padding-top: 75px; padding-bottom: 20px;" alt="Version 1.1" />
                     </div>
                     <h3>DogeSpeedMiner v1.1</h3>
                     Earning rate:<br />
                     52.5 Doge per day<br />
                     5.25% for 30 days<br />
                     <span>Affiliate bonus 6%</span>
                     <button type="button" class="price-button lgb" onclick="go_deps(1000)">Buy for 1000 &#208;</button>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="price-box">
                     <div style="height:180px;">
                        <img class="img-responsive center-block" src="img/tarif/3.png" style="width:140px; padding-top: 34px; padding-bottom: 20px;" alt="Version 1.2" />
                     </div>
                     <h3>DogeSpeedMiner v1.2</h3>
                     Earning rate:<br />
                     275 Doge per day<br />
                     5.5% for 30 days<br />
                     <span>Affiliate bonus 7%</span>
                     <button type="button" class="price-button lgb" onclick="go_deps(5000)">Buy for 5000 &#208;</button>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="price-box">
                     <div style="height:180px;">
                        <img class="img-responsive center-block" src="img/tarif/4.png" style="width:140px; padding-top: 3px; padding-bottom: 20px;" alt="Version 2.0" />
                     </div>
                     <h3>DogeSpeedMiner v2.0</h3>
                     Earning rate:<br />
                     3000 Doge per day<br />
                     6% for 30 days<br />
                     <span>Affiliate bonus 8%</span>
                     <button type="button" class="price-button lgb" onclick="go_deps(50000)">Buy for 50000 &#208;</button>
                  </div>
               </div>

            </div>

            <div class="row" id='doge-pro4' style="display:none;">
               <div class="col-md-3">
                  <div class="price-box">

                     <img class="img-responsive center-block" src="img/tarif/_1.png" style="width:140px; padding-top: 115px; padding-bottom: 20px;" alt="Version 1.0" />

                     <h3 style="color:#1d618c;">DogeSpeedMiner Pro v1.0</h3>
                     Earning rate:<br />
                     14875 Doge per day<br />
                     5.95% for 30 days<br />
                     <span>Affiliate bonus 10%</span>
                     <button type="button" class="price-button-mars lgb" onclick="go_deps_pro(250000)">Buy for 250,000 &#208;</button>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="price-box">
                     <div style="height:180px;">
                        <img class="img-responsive center-block" src="img/tarif/_2.png" style="width:140px; padding-top: 75px; padding-bottom: 20px;" alt="Version 1.1" />
                     </div>
                     <h3 style="color:#1d618c;">DogeSpeedMiner Pro v1.1</h3>
                     Earning rate:<br />
                     46875 Doge per day<br />
                     6.25% for 30 days<br />
                     <span>Affiliate bonus 10%</span>
                     <button type="button" class="price-button-mars lgb" onclick="go_deps_pro(750000)">Buy for 750,000 &#208;</button>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="price-box">
                     <div style="height:180px;">
                        <img class="img-responsive center-block" src="img/tarif/_3.png" style="width:140px; padding-top: 34px; padding-bottom: 20px;" alt="Version 1.2" />
                     </div>
                     <h3 style="color:#1d618c;">DogeSpeedMiner Pro v1.2</h3>
                     Earning rate:<br />
                     97500 Doge per day<br />
                     6.5% for 30 days<br />
                     <span>Affiliate bonus 10%</span>
                     <button type="button" class="price-button-mars lgb" onclick="go_deps_pro(1500000)">Buy for 1,500,000  &#208;</button>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="price-box">
                     <div style="height:180px;">
                        <img class="img-responsive center-block" src="img/tarif/_4.png" style="width:140px; padding-top: 3px; padding-bottom: 20px;" alt="Version 2.0" />
                     </div>
                     <h3 style="color:#1d618c;">DogeSpeedMiner Pro v2.0</h3>
                     Earning rate:<br />
                     210000 Doge per day<br />
                     7% for 30 days<br />
                     <span>Affiliate bonus 10%</span>
                     <button type="button" class="price-button-mars lgb" onclick="go_deps_pro(3000000)">Buy for  3,000,000  &#208;</button>
                  </div>
               </div>

            </div>
         </div>
      </div>
                   <div class="modal-auth">
					 <div class="overlay"></div>
					 <div class="modal-dialog">
						<div class="modal-header">
						   Complete your Deposit
						</div>
						<div class="modal-cont">
						   <p id="pl_wait"><img src="/img/ajax-load.gif"><br />Please wait...</p>
						   <div id="result_dep" style="display:none;"></div>
						</div>
						<div class="modal-footer">
						   <span class="modal_close">Close</span>
						</div>
					 </div>
				  </div>
    
      <div class="mine-result">
         <div class="container">
            <div class="row">
               <div class="col-md-9">
                  <h2>Our mining results</h2>
                  <div class="row">
                     <div class="col-md-4">
                        <span>+5%</span>
                        <div class="clearfix"></div>
                        The average daily profit
                     </div>
                     <div class="col-md-4">
                        <span>+150%</span>
                        <div class="clearfix"></div>
                        The average monthly profit
                     </div>
                     <div class="col-md-4">
                        <span>+1800%</span>
                        <div class="clearfix"></div>
                        The average profit per year
                     </div>
                  </div>
               </div>
               <div class="col-md-3">
                  <a href="/payouts.php" class="result-button">See payment proofs</a>
               </div>
            </div>
         </div>
      </div>
 <div class="footer">
         <div class="container">
            © Dogecoin Speed Miner 2018.<br />
           <br>
           <br>
         </div>
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/global1.js"></script>
   </body>
</html>