

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>DogeSpeedMiner.com - Invest like rich</title>
      <link href="img/dogeminer-favicon.png?s=17032018" rel="shortcut icon" type="image/x-icon" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style2.css?s=03042018-99994">
	   
	   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119885155-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119885155-1');
</script>

      <style>
         #blink5 {
         -webkit-animation: blink5 2s linear infinite;
         animation: blink5 2s linear infinite;
         }
         @-webkit-keyframes blink5 {
         0% { color: rgb(0, 0, 0); }
         50% { color: rgb(125, 4, 40); }
         100% { color: rgb(237, 8, 77); }
         }
         @keyframes blink5 {
         0% { color: rgb(0, 0, 0); }
         50% { color: rgb(125, 4, 40); }
         100% { color: rgb(237, 8, 77); }
         }
      </style>
   </head>
   <body>
      <div class="topmenu">
         <div class="container">
            <ul>
               <li><a href="/index.php">Home</a></li>
			                  <li><a href="/payouts.php">Stats</a></li>
               
               <li><a href="/faq.php">FAQ</a></li>
               <li><a href="/contacts.php">Contacts</a></li>
            </ul>
            <div class="clearfix"></div>
         </div>
      </div>
      <div class="top-bar">
         <div class="container">
            Mining begins immediately. DogeSpeedMiner Free Version 2% per day for 30 days.
         </div>
      </div>
      <a href="#" class="logo-block">
          <span id='logo-change' class="logo"></span>
      </a>
	   
	   
<div class="top-bg" id="header">
   <div class="top-bg-dark"></div>
   <div class="container">
      <h1>Have some questions?</h1>
      <p>Before you ask the question support service operator, please carefully read the FAQ section and if you didn't find the answer to your question, contact our customer support below.</p>
      <div class="head-login" id="enter_result" style="display:none;">
         <div class="login-info">
            <div id="result"></div>
         </div>
      </div>
   </div>
</div>
<div class="wrapper white-box">
   <div class="container">
      <div class="contact-box">
         <h2 class="wrap-title">Our Contacts</h2>
         <input type="text" placeholder="Your name" name="mail_name" id="mail_name" maxlength="255"><br />
         <input type="text" placeholder="Your e-mail" name="mail_email" id="mail_email" maxlength="255"><br />
         <textarea rows="6" placeholder="Your message" name="mail_message" id="mail_message" maxlength="1000"></textarea>
         <button id="go_mail" type="submit" onclick="go_mail()">Send Message</button>
         <div class="clearfix"></div>
      </div>
   </div>
</div>


 <div class="footer">
         <div class="container">
            © Dogecoin Speed Miner 2018.<br />
           <br>
           <br>
         </div>
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/global1.js"></script>
   </body>
</html>