

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>DogeSpeedMiner.com - Invest like rich</title>
      <link href="img/dogeminer-favicon.png?s=17032018" rel="shortcut icon" type="image/x-icon" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style2.css?s=03042018-99994">
	   
	   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119885155-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119885155-1');
</script>

      <style>
         #blink5 {
         -webkit-animation: blink5 2s linear infinite;
         animation: blink5 2s linear infinite;
         }
         @-webkit-keyframes blink5 {
         0% { color: rgb(0, 0, 0); }
         50% { color: rgb(125, 4, 40); }
         100% { color: rgb(237, 8, 77); }
         }
         @keyframes blink5 {
         0% { color: rgb(0, 0, 0); }
         50% { color: rgb(125, 4, 40); }
         100% { color: rgb(237, 8, 77); }
         }
      </style>
   </head>
   <body>
      <div class="topmenu">
         <div class="container">
            <ul>
               <li><a href="/index.php">Home</a></li>
			                  <li><a href="/payouts.php">Stats</a></li>
               
               <li><a href="/faq.php">FAQ</a></li>
               <li><a href="/contacts.php">Contacts</a></li>
            </ul>
            <div class="clearfix"></div>
         </div>
      </div>
      <div class="top-bar">
         <div class="container">
            Mining begins immediately. DogeSpeedMiner Free Version 2% per day for 30 days.
         </div>
      </div>
      <a href="#" class="logo-block">
          <span id='logo-change' class="logo"></span>
      </a>
	   
	   <div class="top-bg" id="header">
   <div class="top-bg-dark"></div>
   <div class="container">
      <h1>Frequently Asked Questions</h1>
      <p>If you need any additional information related to registration and use of our service, detailed instructions or something else, this secton is for you. In case required information has not been found, you can ask for clarification from the customer support service using our <a href="/contacts.php">contact</a> form.</p>
   </div>
</div>
<div class="wrapper white-box">
   <div class="container">
      <div class="faq-box">
         <div class="faq-item">
            <h2>What is <font class="notranslate">DogeSpeedMiner</font>?</h2>
            <p><font class="notranslate">DogeSpeedMiner</font> is an industry leading Dogecoin mining pool. All of the mining power is backed up by physical miners. Mining with the latest algorithms allows to make as much Dogecoin as possible. We aim to provide you with the easiest possible way to make money without having to do any of the hard stuff. </p>
            <p>With data centers around the globe, we aim to keep bills down and mining power high, meaning you can make more in a shorter amount of time than what it would take to mine from your home for instance. Our data centers are located in Europe, USA and China with dedicated Up-Links and 99% uptime!</p>
         </div>
         <div class="faq-item">
            <h2>When did the project start working?</h2>
            <p>12018-05-26 18:14:17</p>
         </div>
         <div class="faq-item">
            <h2>Do you have a video tutorial?</h2>
            <p>Yes:
               <br />1. <a style="cursor:pointer; font-size: 14px;" onclick="video(1)">How to create wallet Dogecoin?</a>
               <br />2. <a style="cursor:pointer; font-size: 14px;" onclick="video(2)">How to register on dogespeedminer.com?</a>
               <br />3. <a style="cursor:pointer; font-size: 14px;" onclick="video(3)">Miners overview.</a>
               <br />4. <a style="cursor:pointer; font-size: 14px;" onclick="video(4)">How to make deposit on dogespeedminer.com?</a>
               <br />5. <a style="cursor:pointer; font-size: 14px;" onclick="video(5)">How to make a withdraw?</a>
               <br />6. <a style="cursor:pointer; font-size: 14px;" onclick="video(6)">How to reinvest your balance?</a>
            </p>
         </div>
         <div class="faq-item">
            <h2>How do I Start?</h2>
            <p>Sign up providing your wallet address and Start generating Dogecoin. </p>
         </div>
         <div class="faq-item">
            <h2>I don't have a Dogecoin wallet. How can I create one?</h2>
            <p>You can create Dogecoin wallet using online services like <a href="http://dogechain.info" target="_blank">dogechain.info</a>.</p>
         </div>
         <div class="faq-item">
            <h2>I don't have Dogecoin. Where can I get Dogecoin?</h2>
            <p>You can buy and sell Dogecoin on exchanges like <a href="http://okex.com" target="_blank">okex.com</a>,
               <a href="http://huobi.pro" target="_blank">huobi.pro</a>,
               <a href="http://binance.com" target="_blank">binance.com</a>,
               <a href="http://bitfinex.com" target="_blank">bitfinex.com</a>,
               <a href="http://upbit.com" target="_blank">upbit.com</a>,
               <a href="http://bithumb.com" target="_blank">bithumb.com</a>,
               <a href="http://gdax.com" target="_blank">gdax.com</a>,
               <a href="http://kraken.com" target="_blank">kraken.com</a>,
               <a href="http://bitstamp.net" target="_blank">bitstamp.net</a>,
               <a href="http://bittrex.com" target="_blank">bittrex.com</a>. Also you can use exchange service: <a href="https://www.changer.com/en/" target="_blank">changer.com</a>, <a href="https://24paybank.com/" target="_blank">24paybank.com</a>, <a href="https://prostocash.com/" target="_blank">prostocash.com</a>, <a href="https://ychanger.net/" target="_blank">ychanger.net</a>.
            </p>
         </div>
         <div class="faq-item">
            <h2>How to change the address of the Dogecoin wallet?</h2>
            <p>Wallet can not change.</p>
         </div>
         <div class="faq-item">
            <h2>How much can I earn without investments?</h2>
            <p>You can generate 0.2 DOGE every day without investments. You can also upgrade your <font class="notranslate">DogeSpeedMiner</font> to generate up to 50000+ DOGE every day.</p>
         </div>
         <div class="faq-item">
            <h2>How much can I earn on the partnership program?</h2>
            <p>You will earn 2% to 8% every time your referral gets upgrade depending on your <font class="notranslate">DogeSpeedMiner</font> version. If you have DogeSpeedMiner V1.0 - your profit will be 5%, 6% for V1.1, 7% for V1.2, 8% for V2.0.</p>
         </div>
         <div class="faq-item">
            <h2>How long does it takes to withdraw money?</h2>
            <p>Withdrawal applications are generally processed instantly, in rare cases withdrawals can be processed manually and take longer.</p>
         </div>
         <div class="faq-item">
            <h2>How long does it takes to receive a deposit?</h2>
            <p>1-60 minutes.</p>
         </div>

         <div class="faq-item">
            <h2>What is the minimum amount for withdrawal and upgrade?</h2>
            <p>Minimum withdrawal amount is 20 DOGE, 1-4 DOGE transaction fee. Minimal upgrade amount is 300 DOGE.</p>
         </div>
         <div class="faq-item">
            <h2>I sent less than 300 DOGE, what should I do?</h2>
            <p>You need to send the remaining amount to the same address.</p>
         </div>
         <div class="faq-item">
            <h2>If I pay for an upgrade how long is it active?</h2>
            <p>DogeSpeedMiner upgrades works for 30 days.</p>
         </div>
         <div class="faq-item">
            <h2>Can I upgrade <font class="notranslate">DogeSpeedMiner</font> with money on my balance?</h2>
            <p>Yes.</p>
         </div>
         <div class="faq-item">
            <h2>Is there a lifetime of my account?</h2>
            <p>Yes, the account is deleted if there was no activity on it for 30 days.</p>
         </div>
         <div class="faq-item">
            <h2>Can I buy more than one miner?</h2>
            <p>Yes, of course, you can buy any number of miners, their power is summed.</p>
         </div>
         <div class="faq-item">
            <h2>How long does the contract last?</h2>
            <p>30 days from the date of purchase.</p>
         </div>
         <div class="faq-item">
            <h2>I haven't found an answer to my question. How can I get in touch with you?</h2>
            <p>You can get in touch with us via our <a href="/contacts.php">contacts page</a>.</p>
         </div>
         <div class="faq-item">
            <h2>Does it allowed to have multiple accounts?</h2>
            <p>Yes, you can have multiple wallets added to the system but they should not be registered using your referral link from another wallet. In case of violation of this prohibition your wallet will be banned without return your deposit/funds.</p>
         </div>
         <div class="clearfix"></div>
      </div>
   </div>
</div>
<div class="modal-auth">
   <div class="overlay"></div>
   <div class="modal-dialog">
      <div class="modal-header">
         Tutorial Video
      </div>
      <div class="modal-cont">
         <p id="pl_wait"><img src="/img/ajax-load.gif"><br />Please wait...</p>
         <div id="result_dep" style="display:none;"></div>
      </div>
      <div class="modal-footer">
         <span class="modal_close">Close</span>
      </div>
   </div>
</div>
 <div class="footer">
         <div class="container">
            © Dogecoin Speed Miner 2018.<br />
           <br>
           <br>
         </div>
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/global1.js"></script>
   </body>
</html>